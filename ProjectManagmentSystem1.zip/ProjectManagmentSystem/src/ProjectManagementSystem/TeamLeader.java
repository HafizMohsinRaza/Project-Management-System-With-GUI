package ProjectManagementSystem;

public class TeamLeader {
//Make consturctors here
    public void CreateTask() {
        
    }
// make him super man :)  he can assign task/
    //  or edit/delete them  to him or to others
    public void EditTask(Task task) {
        
    }

    public void DeleteTask(Task task) {
        
    }

    public void AssignTask(TeamMember member) {
        
        
    }

    public void UnAssignTask(TeamMember member) {
        
        
    }
}
