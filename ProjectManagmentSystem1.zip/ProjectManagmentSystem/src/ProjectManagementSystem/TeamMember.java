package ProjectManagementSystem;

public class TeamMember extends TeamLeader {
//Make consturctors here

    public void BrowseTasks(Task task) {
    }

    public void DisplayAssignedTask(Task task) {
    }

    @Override // Make him edits his tasks status only !
    public void EditTask(Task task) {
        
        
    }

    public void ChangeTaskStatus(Task task) {
    }
}
